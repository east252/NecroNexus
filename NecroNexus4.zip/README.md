# NecroNexus

A 7 Days to Die Server Manager  

### Features
- Install Steam
- Install Server
- Start/Stop/Kill Server
- Terminal output to view logs
- Log Split - View Error/Normal logs
- Program File, Save Folder, Log Folder button for fast access
- Auto Restart
- Experimental mode to install latest experimental
